<?php

require_once __DIR__ . '/../model/PatientModel.php';
require_once __DIR__ . '/../model/ReportModel.php';

class PatientController
{
    private PatientModel $patientModel;
    private ReportModel $reportModel;

    public function __construct()
    {
        $this->patientModel = new PatientModel();
        $this->reportModel = new ReportModel();
    }

    private function ensureDoctorIsAuthenticated(): int
    {
        if (!isset($_SESSION['doctor_id'])) {
            header('Location: index.php?action=login');
            exit;
        }
        return (int)$_SESSION['doctor_id'];
    }

    public function index(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $patientList = $this->patientModel->getPatientsByDoctorId($doctorIdentifier);
        require __DIR__ . '/../view/patient_list.php';
    }

    public function create(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $errorMessage = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $patientName = trim($_POST['name'] ?? '');
            $patientAge = (int)($_POST['age'] ?? 0);
            $patientGender = trim($_POST['gender'] ?? '');

            if (empty($patientName) || $patientAge <= 0 || empty($patientGender)) {
                $errorMessage = 'Please provide valid values for all patient fields.';
            } else {
                $creationSuccessful = $this->patientModel->createPatient(
                    $doctorIdentifier,
                    $patientName,
                    $patientAge,
                    $patientGender
                );

                if ($creationSuccessful) {
                    header('Location: index.php?action=patients&created=1');
                    exit;
                } else {
                    $errorMessage = 'Failed to register the patient.';
                }
            }
        }

        require __DIR__ . '/../view/patient_create.php';
    }

    public function view(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $patientIdentifier = (int)($_GET['id'] ?? 0);

        $patientRecord = $this->patientModel->getPatientByIdAndDoctorId($patientIdentifier, $doctorIdentifier);

        if (!$patientRecord) {
            header('Location: index.php?action=patients&error=notfound');
            exit;
        }

        $reportList = $this->reportModel->getReportsByPatientIdAndDoctorId($patientIdentifier, $doctorIdentifier);

        require __DIR__ . '/../view/patient_view.php';
    }
}
