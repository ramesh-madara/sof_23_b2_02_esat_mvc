<?php

require_once __DIR__ . '/../model/PatientModel.php';
require_once __DIR__ . '/../model/ReportModel.php';
require_once __DIR__ . '/../libs/fpdf.php';

class ReportController
{
    private PatientModel $patientModel;
    private ReportModel $reportModel;

    public function __construct()
    {
        $this->patientModel = new PatientModel();
        $this->reportModel = new ReportModel();
    }

    private function ensureDoctorIsAuthenticated(): int
    {
        if (!isset($_SESSION['doctor_id'])) {
            header('Location: index.php?action=login');
            exit;
        }
        return (int)$_SESSION['doctor_id'];
    }

    public function create(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $patientIdentifier = (int)($_GET['patient_id'] ?? 0);

        $patientRecord = $this->patientModel->getPatientByIdAndDoctorId($patientIdentifier, $doctorIdentifier);

        if (!$patientRecord) {
            header('Location: index.php?action=patients&error=unauthorized');
            exit;
        }

        $errorMessage = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $reportType = trim($_POST['report_type'] ?? '');
            $bloodTestResults = [];

            if ($reportType === 'FBC') {
                $bloodTestResults = [
                    'Hemoglobin (g/dL)' => trim($_POST['hemoglobin'] ?? ''),
                    'White Blood Cell Count (x10^9/L)' => trim($_POST['white_blood_cells'] ?? ''),
                    'Red Blood Cell Count (x10^12/L)' => trim($_POST['red_blood_cells'] ?? ''),
                    'Platelet Count (x10^9/L)' => trim($_POST['platelets'] ?? ''),
                    'Hematocrit (%)' => trim($_POST['hematocrit'] ?? ''),
                ];
            } elseif ($reportType === 'Lipid Profile') {
                $bloodTestResults = [
                    'Total Cholesterol (mg/dL)' => trim($_POST['total_cholesterol'] ?? ''),
                    'Triglycerides (mg/dL)' => trim($_POST['triglycerides'] ?? ''),
                    'HDL Cholesterol (mg/dL)' => trim($_POST['hdl_cholesterol'] ?? ''),
                    'LDL Cholesterol (mg/dL)' => trim($_POST['ldl_cholesterol'] ?? ''),
                ];
            } elseif ($reportType === 'Blood Sugar') {
                $bloodTestResults = [
                    'Fasting Blood Sugar (mg/dL)' => trim($_POST['fasting_blood_sugar'] ?? ''),
                    'Postprandial Blood Sugar (mg/dL)' => trim($_POST['postprandial_blood_sugar'] ?? ''),
                    'HbA1c (%)' => trim($_POST['hba1c'] ?? ''),
                ];
            } else {
                $errorMessage = 'Invalid blood report type selected.';
            }

            if (empty($errorMessage)) {
                $reportDataJson = json_encode($bloodTestResults);
                $creationSuccessful = $this->reportModel->createReport(
                    $patientIdentifier,
                    $doctorIdentifier,
                    $reportType,
                    $reportDataJson
                );

                if ($creationSuccessful) {
                    header('Location: index.php?action=patient_view&id=' . $patientIdentifier . '&report_created=1');
                    exit;
                } else {
                    $errorMessage = 'Failed to generate blood report.';
                }
            }
        }

        require __DIR__ . '/../view/report_create.php';
    }

    public function view(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $reportIdentifier = (int)($_GET['id'] ?? 0);

        $reportRecord = $this->reportModel->getReportByIdAndDoctorId($reportIdentifier, $doctorIdentifier);

        if (!$reportRecord) {
            header('Location: index.php?action=patients&error=notfound');
            exit;
        }

        $bloodTestResults = json_decode($reportRecord['data'], true) ?? [];

        require __DIR__ . '/../view/report_view.php';
    }

    public function edit(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $reportIdentifier = (int)($_GET['id'] ?? 0);

        $reportRecord = $this->reportModel->getReportByIdAndDoctorId($reportIdentifier, $doctorIdentifier);

        if (!$reportRecord) {
            header('Location: index.php?action=patients&error=unauthorized');
            exit;
        }

        $errorMessage = '';
        $bloodTestResults = json_decode($reportRecord['data'], true) ?? [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $reportType = trim($_POST['report_type'] ?? '');
            $newTestResults = [];

            if ($reportType === 'FBC') {
                $newTestResults = [
                    'Hemoglobin (g/dL)' => trim($_POST['hemoglobin'] ?? ''),
                    'White Blood Cell Count (x10^9/L)' => trim($_POST['white_blood_cells'] ?? ''),
                    'Red Blood Cell Count (x10^12/L)' => trim($_POST['red_blood_cells'] ?? ''),
                    'Platelet Count (x10^9/L)' => trim($_POST['platelets'] ?? ''),
                    'Hematocrit (%)' => trim($_POST['hematocrit'] ?? ''),
                ];
            } elseif ($reportType === 'Lipid Profile') {
                $newTestResults = [
                    'Total Cholesterol (mg/dL)' => trim($_POST['total_cholesterol'] ?? ''),
                    'Triglycerides (mg/dL)' => trim($_POST['triglycerides'] ?? ''),
                    'HDL Cholesterol (mg/dL)' => trim($_POST['hdl_cholesterol'] ?? ''),
                    'LDL Cholesterol (mg/dL)' => trim($_POST['ldl_cholesterol'] ?? ''),
                ];
            } elseif ($reportType === 'Blood Sugar') {
                $newTestResults = [
                    'Fasting Blood Sugar (mg/dL)' => trim($_POST['fasting_blood_sugar'] ?? ''),
                    'Postprandial Blood Sugar (mg/dL)' => trim($_POST['postprandial_blood_sugar'] ?? ''),
                    'HbA1c (%)' => trim($_POST['hba1c'] ?? ''),
                ];
            } else {
                $errorMessage = 'Invalid blood report type selected.';
            }

            if (empty($errorMessage)) {
                $reportDataJson = json_encode($newTestResults);
                $updateSuccessful = $this->reportModel->updateReport(
                    $reportIdentifier,
                    $doctorIdentifier,
                    $reportType,
                    $reportDataJson
                );

                if ($updateSuccessful) {
                    header('Location: index.php?action=report_view&id=' . $reportIdentifier . '&updated=1');
                    exit;
                } else {
                    $errorMessage = 'Failed to update the report.';
                }
            }
        }

        require __DIR__ . '/../view/report_edit.php';
    }

    public function delete(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $reportIdentifier = (int)($_POST['id'] ?? $_GET['id'] ?? 0);

        $reportRecord = $this->reportModel->getReportByIdAndDoctorId($reportIdentifier, $doctorIdentifier);

        if ($reportRecord) {
            $patientIdentifier = (int)$reportRecord['patient_id'];
            $this->reportModel->deleteReport($reportIdentifier, $doctorIdentifier);
            header('Location: index.php?action=patient_view&id=' . $patientIdentifier . '&deleted=1');
            exit;
        }

        header('Location: index.php?action=patients&error=unauthorized');
        exit;
    }

    public function exportPdf(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $reportIdentifier = (int)($_GET['id'] ?? 0);

        $reportRecord = $this->reportModel->getReportByIdAndDoctorId($reportIdentifier, $doctorIdentifier);

        if (!$reportRecord) {
            header('Location: index.php?action=patients&error=notfound');
            exit;
        }

        $bloodTestResults = json_decode($reportRecord['data'], true) ?? [];

        $pdf = new FPDF();
        $pdf->AddPage();

        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'BLOOD TEST REPORT', 0, 1, 'L');
        $pdf->Ln(4);

        $pdf->SetFont('Arial', '', 11);
        $pdf->Cell(45, 7, 'Patient Name:', 0, 0);
        $pdf->Cell(0, 7, $reportRecord['patient_name'], 0, 1);

        $pdf->Cell(45, 7, 'Patient Age:', 0, 0);
        $pdf->Cell(0, 7, (string)$reportRecord['patient_age'], 0, 1);

        $pdf->Cell(45, 7, 'Patient Gender:', 0, 0);
        $pdf->Cell(0, 7, $reportRecord['patient_gender'], 0, 1);

        $pdf->Cell(45, 7, 'Attending Doctor:', 0, 0);
        $pdf->Cell(0, 7, $_SESSION['doctor_username'], 0, 1);

        $pdf->Cell(45, 7, 'Report Type:', 0, 0);
        $pdf->Cell(0, 7, $reportRecord['type'], 0, 1);

        $pdf->Cell(45, 7, 'Generated Date:', 0, 0);
        $pdf->Cell(0, 7, $reportRecord['created_at'], 0, 1);
        $pdf->Ln(6);

        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(110, 8, 'Test Parameter', 1, 0, 'L');
        $pdf->Cell(70, 8, 'Observed Result', 1, 1, 'L');

        $pdf->SetFont('Arial', '', 10);
        foreach ($bloodTestResults as $testParameter => $testValue) {
            $pdf->Cell(110, 7, (string)$testParameter, 1, 0, 'L');
            $pdf->Cell(70, 7, (string)$testValue, 1, 1, 'L');
        }

        $pdf->Output('I', 'Blood_Report_' . $reportIdentifier . '.pdf');
        exit;
    }
}
