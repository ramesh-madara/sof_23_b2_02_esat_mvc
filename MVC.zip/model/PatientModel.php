<?php

require_once __DIR__ . '/Database.php';

class PatientModel
{
    private PDO $databaseConnection;

    public function __construct()
    {
        $this->databaseConnection = Database::getConnection();
    }

    public function createPatient(int $doctorIdentifier, string $patientName, int $patientAge, string $patientGender): bool
    {
        $statement = $this->databaseConnection->prepare("INSERT INTO patients (doctor_id, name, age, gender) VALUES (:doctor_id, :name, :age, :gender)");
        return $statement->execute([
            ':doctor_id' => $doctorIdentifier,
            ':name' => $patientName,
            ':age' => $patientAge,
            ':gender' => $patientGender,
        ]);
    }

    public function getPatientsByDoctorId(int $doctorIdentifier): array
    {
        $statement = $this->databaseConnection->prepare("SELECT * FROM patients WHERE doctor_id = :doctor_id ORDER BY id DESC");
        $statement->execute([':doctor_id' => $doctorIdentifier]);
        return $statement->fetchAll();
    }

    public function getPatientByIdAndDoctorId(int $patientIdentifier, int $doctorIdentifier): ?array
    {
        $statement = $this->databaseConnection->prepare("SELECT * FROM patients WHERE id = :id AND doctor_id = :doctor_id LIMIT 1");
        $statement->execute([
            ':id' => $patientIdentifier,
            ':doctor_id' => $doctorIdentifier,
        ]);
        $patientRecord = $statement->fetch();
        return $patientRecord ?: null;
    }
}
