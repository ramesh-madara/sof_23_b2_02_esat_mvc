<?php require __DIR__ . '/header.php'; ?>

<div class="panel">
    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px;">
        <div>
            <h2>Blood Test Report #<?php echo htmlspecialchars((string)$reportRecord['id']); ?></h2>
            <div style="font-size: 14px; color: #555555; margin-top: 5px;">
                Generated on: <strong><?php echo htmlspecialchars($reportRecord['created_at']); ?></strong>
            </div>
        </div>
        <div>
            <a href="index.php?action=report_pdf&id=<?php echo urlencode($reportRecord['id']); ?>" target="_blank" class="button">Export PDF</a>
            <a href="index.php?action=report_edit&id=<?php echo urlencode($reportRecord['id']); ?>" class="button secondary">Edit Report</a>
            <a href="index.php?action=patient_view&id=<?php echo urlencode($reportRecord['patient_id']); ?>" class="button secondary">Back to Patient</a>
        </div>
    </div>

    <?php if (isset($_GET['updated'])): ?>
        <div class="alert-success">Report updated successfully.</div>
    <?php endif; ?>

    <div style="background-color: #f7f7f7; border: 1px solid #000000; padding: 15px; margin-bottom: 25px;">
        <table style="border: none; margin: 0;">
            <tr style="border: none;">
                <td style="border: none; padding: 4px 10px; width: 25%;"><strong>Patient Name:</strong></td>
                <td style="border: none; padding: 4px 10px;"><?php echo htmlspecialchars($reportRecord['patient_name']); ?></td>
                <td style="border: none; padding: 4px 10px; width: 25%;"><strong>Report Type:</strong></td>
                <td style="border: none; padding: 4px 10px;"><strong><?php echo htmlspecialchars($reportRecord['type']); ?></strong></td>
            </tr>
            <tr style="border: none;">
                <td style="border: none; padding: 4px 10px;"><strong>Patient Age:</strong></td>
                <td style="border: none; padding: 4px 10px;"><?php echo htmlspecialchars((string)$reportRecord['patient_age']); ?> Years</td>
                <td style="border: none; padding: 4px 10px;"><strong>Attending Doctor:</strong></td>
                <td style="border: none; padding: 4px 10px;"><?php echo htmlspecialchars($_SESSION['doctor_username']); ?></td>
            </tr>
            <tr style="border: none;">
                <td style="border: none; padding: 4px 10px;"><strong>Patient Gender:</strong></td>
                <td style="border: none; padding: 4px 10px;"><?php echo htmlspecialchars($reportRecord['patient_gender']); ?></td>
                <td style="border: none; padding: 4px 10px;"></td>
                <td style="border: none; padding: 4px 10px;"></td>
            </tr>
        </table>
    </div>

    <h3>Observed Test Results</h3>
    <table>
        <thead>
            <tr>
                <th>Test Parameter</th>
                <th style="width: 300px;">Measured Result</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bloodTestResults as $parameterName => $measuredValue): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars((string)$parameterName); ?></strong></td>
                    <td><?php echo htmlspecialchars((string)$measuredValue); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div style="margin-top: 30px; border-top: 1px solid #cccccc; padding-top: 15px; display: flex; justify-content: flex-end;">
        <form method="POST" action="index.php?action=report_delete" onsubmit="return confirm('Are you sure you want to delete this report? This cannot be undone.');">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars((string)$reportRecord['id']); ?>">
            <button type="submit" class="button danger">Delete This Report</button>
        </form>
    </div>
</div>

<?php require __DIR__ . '/footer.php'; ?>
