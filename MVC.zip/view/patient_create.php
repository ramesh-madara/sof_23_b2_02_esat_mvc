<?php require __DIR__ . '/header.php'; ?>

<div class="panel" style="max-width: 550px; margin: 30px auto;">
    <h2>Register New Patient</h2>

    <?php if (!empty($errorMessage)): ?>
        <div class="alert-error"><?php echo htmlspecialchars($errorMessage); ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php?action=patient_create">
        <div>
            <label for="name">Patient Full Name</label>
            <input type="text" id="name" name="name" required autofocus>
        </div>

        <div>
            <label for="age">Age (Years)</label>
            <input type="number" id="age" name="age" min="1" max="130" required>
        </div>

        <div>
            <label for="gender">Gender</label>
            <select id="gender" name="gender" required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select>
        </div>

        <div style="margin-top: 20px;">
            <button type="submit" class="button">Save Patient</button>
            <a href="index.php?action=patients" class="button secondary">Cancel</a>
        </div>
    </form>
</div>

<?php require __DIR__ . '/footer.php'; ?>
