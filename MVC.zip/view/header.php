<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Blood Report Generator</title>
    <style>
        * {
            box-sizing: border-box;
            box-shadow: none !important;
            transition: none !important;
            animation: none !important;
            border-radius: 0 !important;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #ffffff;
            color: #000000;
            margin: 0;
            padding: 0;
            line-height: 1.5;
        }
        .header-bar {
            background-color: #000000;
            color: #ffffff;
            padding: 14px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header-bar a {
            color: #ffffff;
            text-decoration: none;
            font-weight: bold;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .container {
            max-width: 960px;
            margin: 25px auto;
            padding: 0 20px;
        }
        .panel {
            border: 1px solid #000000;
            padding: 20px;
            margin-bottom: 25px;
            background-color: #ffffff;
        }
        h1, h2, h3 {
            margin-top: 0;
            color: #000000;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            margin-bottom: 15px;
        }
        table, th, td {
            border: 1px solid #000000;
        }
        th, td {
            padding: 9px 12px;
            text-align: left;
        }
        th {
            background-color: #eeeeee;
        }
        label {
            display: block;
            margin-top: 12px;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="number"],
        input[type="password"],
        select {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #000000;
            background-color: #ffffff;
            color: #000000;
            font-size: 14px;
        }
        .button {
            display: inline-block;
            background-color: #000000;
            color: #ffffff;
            padding: 8px 16px;
            border: 1px solid #000000;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            margin-right: 5px;
        }
        .button.secondary {
            background-color: #ffffff;
            color: #000000;
            border: 1px solid #000000;
        }
        .button.danger {
            background-color: #ffffff;
            color: #dc3545;
            border: 1px solid #dc3545;
        }
        .alert-success {
            border: 1px solid #28a745;
            background-color: #d4edda;
            color: #155724;
            padding: 10px 15px;
            margin-bottom: 20px;
        }
        .alert-error {
            border: 1px solid #dc3545;
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px 15px;
            margin-bottom: 20px;
        }
        .alert-warning {
            border: 1px solid #ffc107;
            background-color: #fff3cd;
            color: #856404;
            padding: 10px 15px;
            margin-bottom: 20px;
        }
        .field-box {
            border: 1px solid #cccccc;
            padding: 15px;
            margin-top: 15px;
            margin-bottom: 15px;
        }
        .inline-form {
            display: inline;
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>
    <div class="header-bar">
        <div>
            <a href="index.php?action=patients" style="font-size: 18px;">BLOOD REPORT GENERATOR</a>
        </div>
        <div class="nav-links">
            <?php if (isset($_SESSION['doctor_id'])): ?>
                <span>Logged in: <strong><?php echo htmlspecialchars($_SESSION['doctor_username']); ?></strong></span>
                <a href="index.php?action=patients">Patients</a>
                <a href="index.php?action=account">Account</a>
                <a href="index.php?action=logout">Logout</a>
            <?php else: ?>
                <a href="index.php?action=login">Login</a>
                <a href="index.php?action=register">Register</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="container">
