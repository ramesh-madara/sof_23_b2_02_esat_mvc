<?php require __DIR__ . '/header.php'; ?>

<div class="panel" style="max-width: 650px; margin: 25px auto;">
    <h2>Modify Blood Report #<?php echo htmlspecialchars((string)$reportRecord['id']); ?></h2>

    <div style="margin-bottom: 20px; padding: 10px; background-color: #f7f7f7; border: 1px solid #cccccc;">
        <strong>Patient:</strong> <?php echo htmlspecialchars($reportRecord['patient_name']); ?> |
        <strong>Age:</strong> <?php echo htmlspecialchars((string)$reportRecord['patient_age']); ?> |
        <strong>Gender:</strong> <?php echo htmlspecialchars($reportRecord['patient_gender']); ?>
    </div>

    <?php if (!empty($errorMessage)): ?>
        <div class="alert-error"><?php echo htmlspecialchars($errorMessage); ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php?action=report_edit&id=<?php echo urlencode($reportRecord['id']); ?>">
        <div>
            <label for="report_type">Report Type</label>
            <select id="report_type" name="report_type" onchange="toggleTestPanels(this.value);" required>
                <option value="FBC" <?php echo ($reportRecord['type'] === 'FBC') ? 'selected' : ''; ?>>Full Blood Count (FBC)</option>
                <option value="Lipid Profile" <?php echo ($reportRecord['type'] === 'Lipid Profile') ? 'selected' : ''; ?>>Lipid Profile</option>
                <option value="Blood Sugar" <?php echo ($reportRecord['type'] === 'Blood Sugar') ? 'selected' : ''; ?>>Blood Sugar</option>
            </select>
        </div>

        <div id="panel_fbc" class="field-box" style="<?php echo ($reportRecord['type'] === 'FBC') ? 'display: block;' : 'display: none;'; ?>">
            <h3>Full Blood Count (FBC) Parameters</h3>
            <div>
                <label for="hemoglobin">Hemoglobin (g/dL)</label>
                <input type="text" id="hemoglobin" name="hemoglobin" value="<?php echo htmlspecialchars($bloodTestResults['Hemoglobin (g/dL)'] ?? ''); ?>">
            </div>
            <div>
                <label for="white_blood_cells">White Blood Cell Count (x10^9/L)</label>
                <input type="text" id="white_blood_cells" name="white_blood_cells" value="<?php echo htmlspecialchars($bloodTestResults['White Blood Cell Count (x10^9/L)'] ?? ''); ?>">
            </div>
            <div>
                <label for="red_blood_cells">Red Blood Cell Count (x10^12/L)</label>
                <input type="text" id="red_blood_cells" name="red_blood_cells" value="<?php echo htmlspecialchars($bloodTestResults['Red Blood Cell Count (x10^12/L)'] ?? ''); ?>">
            </div>
            <div>
                <label for="platelets">Platelet Count (x10^9/L)</label>
                <input type="text" id="platelets" name="platelets" value="<?php echo htmlspecialchars($bloodTestResults['Platelet Count (x10^9/L)'] ?? ''); ?>">
            </div>
            <div>
                <label for="hematocrit">Hematocrit (%)</label>
                <input type="text" id="hematocrit" name="hematocrit" value="<?php echo htmlspecialchars($bloodTestResults['Hematocrit (%)'] ?? ''); ?>">
            </div>
        </div>

        <div id="panel_lipid" class="field-box" style="<?php echo ($reportRecord['type'] === 'Lipid Profile') ? 'display: block;' : 'display: none;'; ?>">
            <h3>Lipid Profile Parameters</h3>
            <div>
                <label for="total_cholesterol">Total Cholesterol (mg/dL)</label>
                <input type="text" id="total_cholesterol" name="total_cholesterol" value="<?php echo htmlspecialchars($bloodTestResults['Total Cholesterol (mg/dL)'] ?? ''); ?>">
            </div>
            <div>
                <label for="triglycerides">Triglycerides (mg/dL)</label>
                <input type="text" id="triglycerides" name="triglycerides" value="<?php echo htmlspecialchars($bloodTestResults['Triglycerides (mg/dL)'] ?? ''); ?>">
            </div>
            <div>
                <label for="hdl_cholesterol">HDL Cholesterol (mg/dL)</label>
                <input type="text" id="hdl_cholesterol" name="hdl_cholesterol" value="<?php echo htmlspecialchars($bloodTestResults['HDL Cholesterol (mg/dL)'] ?? ''); ?>">
            </div>
            <div>
                <label for="ldl_cholesterol">LDL Cholesterol (mg/dL)</label>
                <input type="text" id="ldl_cholesterol" name="ldl_cholesterol" value="<?php echo htmlspecialchars($bloodTestResults['LDL Cholesterol (mg/dL)'] ?? ''); ?>">
            </div>
        </div>

        <div id="panel_sugar" class="field-box" style="<?php echo ($reportRecord['type'] === 'Blood Sugar') ? 'display: block;' : 'display: none;'; ?>">
            <h3>Blood Sugar Parameters</h3>
            <div>
                <label for="fasting_blood_sugar">Fasting Blood Sugar (mg/dL)</label>
                <input type="text" id="fasting_blood_sugar" name="fasting_blood_sugar" value="<?php echo htmlspecialchars($bloodTestResults['Fasting Blood Sugar (mg/dL)'] ?? ''); ?>">
            </div>
            <div>
                <label for="postprandial_blood_sugar">Postprandial Blood Sugar (mg/dL)</label>
                <input type="text" id="postprandial_blood_sugar" name="postprandial_blood_sugar" value="<?php echo htmlspecialchars($bloodTestResults['Postprandial Blood Sugar (mg/dL)'] ?? ''); ?>">
            </div>
            <div>
                <label for="hba1c">HbA1c (%)</label>
                <input type="text" id="hba1c" name="hba1c" value="<?php echo htmlspecialchars($bloodTestResults['HbA1c (%)'] ?? ''); ?>">
            </div>
        </div>

        <div style="margin-top: 20px;">
            <button type="submit" class="button">Update Report</button>
            <a href="index.php?action=report_view&id=<?php echo urlencode($reportRecord['id']); ?>" class="button secondary">Cancel</a>
        </div>
    </form>
</div>

<script>
function toggleTestPanels(selectedType) {
    document.getElementById('panel_fbc').style.display = (selectedType === 'FBC') ? 'block' : 'none';
    document.getElementById('panel_lipid').style.display = (selectedType === 'Lipid Profile') ? 'block' : 'none';
    document.getElementById('panel_sugar').style.display = (selectedType === 'Blood Sugar') ? 'block' : 'none';
}
</script>

<?php require __DIR__ . '/footer.php'; ?>
