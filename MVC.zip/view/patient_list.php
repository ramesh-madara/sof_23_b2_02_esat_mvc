<?php require __DIR__ . '/header.php'; ?>

<div class="panel">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
        <h2>My Patients</h2>
        <a href="index.php?action=patient_create" class="button">Register New Patient</a>
    </div>

    <?php if (isset($_GET['created'])): ?>
        <div class="alert-success">Patient registered successfully.</div>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert-error">The requested record could not be found or access is denied.</div>
    <?php endif; ?>

    <?php if (empty($patientList)): ?>
        <div class="alert-warning">No patients registered under your account yet.</div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th style="width: 80px;">ID</th>
                    <th>Full Name</th>
                    <th style="width: 80px;">Age</th>
                    <th style="width: 120px;">Gender</th>
                    <th style="width: 240px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($patientList as $patientRecord): ?>
                    <tr>
                        <td>#<?php echo htmlspecialchars((string)$patientRecord['id']); ?></td>
                        <td><strong><?php echo htmlspecialchars($patientRecord['name']); ?></strong></td>
                        <td><?php echo htmlspecialchars((string)$patientRecord['age']); ?></td>
                        <td><?php echo htmlspecialchars($patientRecord['gender']); ?></td>
                        <td>
                            <a href="index.php?action=patient_view&id=<?php echo urlencode($patientRecord['id']); ?>" class="button">View Records</a>
                            <a href="index.php?action=report_create&patient_id=<?php echo urlencode($patientRecord['id']); ?>" class="button secondary">Add Report</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/footer.php'; ?>
