<?php require __DIR__ . '/header.php'; ?>

<div class="panel" style="max-width: 450px; margin: 40px auto;">
    <h2>Doctor Login</h2>

    <?php if (isset($_GET['registered'])): ?>
        <div class="alert-success">Account created successfully. You may now sign in.</div>
    <?php endif; ?>

    <?php if (!empty($errorMessage)): ?>
        <div class="alert-error"><?php echo htmlspecialchars($errorMessage); ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php?action=login">
        <div>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required autofocus>
        </div>

        <div>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>

        <div style="margin-top: 20px;">
            <button type="submit" class="button">Log In</button>
        </div>
    </form>

    <div style="margin-top: 20px; font-size: 14px;">
        Need an account? <a href="index.php?action=register" style="color: #000000; font-weight: bold;">Register here</a>.
    </div>
</div>

<?php require __DIR__ . '/footer.php'; ?>
