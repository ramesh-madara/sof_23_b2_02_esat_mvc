<?php require __DIR__ . '/header.php'; ?>

<div class="panel" style="max-width: 550px; margin: 30px auto;">
    <h2>Doctor Account Management</h2>

    <?php if (!empty($successMessage)): ?>
        <div class="alert-success"><?php echo htmlspecialchars($successMessage); ?></div>
    <?php endif; ?>

    <?php if (!empty($errorMessage)): ?>
        <div class="alert-error"><?php echo htmlspecialchars($errorMessage); ?></div>
    <?php endif; ?>

    <div style="margin-bottom: 25px; padding: 12px; background-color: #f7f7f7; border: 1px solid #cccccc;">
        <div><strong>Username:</strong> <?php echo htmlspecialchars($doctorRecord['username'] ?? ''); ?></div>
        <div><strong>Doctor ID:</strong> <?php echo htmlspecialchars((string)($doctorRecord['id'] ?? '')); ?></div>
    </div>

    <h3>Change Password</h3>
    <form method="POST" action="index.php?action=account">
        <div>
            <label for="current_password">Current Password</label>
            <input type="password" id="current_password" name="current_password" required>
        </div>

        <div>
            <label for="new_password">New Password</label>
            <input type="password" id="new_password" name="new_password" required>
        </div>

        <div>
            <label for="confirm_password">Confirm New Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>

        <div style="margin-top: 20px;">
            <button type="submit" class="button">Update Password</button>
            <a href="index.php?action=patients" class="button secondary">Back to Patients</a>
        </div>
    </form>
</div>

<?php require __DIR__ . '/footer.php'; ?>
