<?php require __DIR__ . '/header.php'; ?>

<div class="panel" style="max-width: 450px; margin: 40px auto;">
    <h2>Register Doctor Account</h2>

    <?php if (!empty($errorMessage)): ?>
        <div class="alert-error"><?php echo htmlspecialchars($errorMessage); ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php?action=register">
        <div>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required autofocus>
        </div>

        <div>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>

        <div>
            <label for="confirm_password">Confirm Password</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>

        <div style="margin-top: 20px;">
            <button type="submit" class="button">Create Account</button>
        </div>
    </form>

    <div style="margin-top: 20px; font-size: 14px;">
        Already have an account? <a href="index.php?action=login" style="color: #000000; font-weight: bold;">Login here</a>.
    </div>
</div>

<?php require __DIR__ . '/footer.php'; ?>
