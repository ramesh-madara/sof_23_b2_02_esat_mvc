<?php require __DIR__ . '/header.php'; ?>

<div class="panel">
    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
        <div>
            <h2>Patient Record: <?php echo htmlspecialchars($patientRecord['name']); ?></h2>
            <div style="margin-top: 5px; font-size: 15px; color: #444444;">
                <span><strong>ID:</strong> #<?php echo htmlspecialchars((string)$patientRecord['id']); ?></span> |
                <span><strong>Age:</strong> <?php echo htmlspecialchars((string)$patientRecord['age']); ?></span> |
                <span><strong>Gender:</strong> <?php echo htmlspecialchars($patientRecord['gender']); ?></span>
            </div>
        </div>
        <div>
            <a href="index.php?action=report_create&patient_id=<?php echo urlencode($patientRecord['id']); ?>" class="button">Create New Report</a>
            <a href="index.php?action=patients" class="button secondary">Back to Patients</a>
        </div>
    </div>
</div>

<div class="panel">
    <h3>Blood Reports History</h3>

    <?php if (isset($_GET['report_created'])): ?>
        <div class="alert-success">Blood test report generated successfully.</div>
    <?php endif; ?>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert-success">Report deleted successfully.</div>
    <?php endif; ?>

    <?php if (empty($reportList)): ?>
        <div class="alert-warning">No blood reports found for this patient.</div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th style="width: 80px;">Report ID</th>
                    <th>Report Type</th>
                    <th style="width: 220px;">Date Generated</th>
                    <th style="width: 330px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reportList as $reportRecord): ?>
                    <tr>
                        <td>#<?php echo htmlspecialchars((string)$reportRecord['id']); ?></td>
                        <td><strong><?php echo htmlspecialchars($reportRecord['type']); ?></strong></td>
                        <td><?php echo htmlspecialchars($reportRecord['created_at']); ?></td>
                        <td class="actions-cell">
                            <a href="index.php?action=report_view&id=<?php echo urlencode($reportRecord['id']); ?>" class="button">View</a>
                            <a href="index.php?action=report_edit&id=<?php echo urlencode($reportRecord['id']); ?>" class="button secondary">Edit</a>
                            <a href="index.php?action=report_pdf&id=<?php echo urlencode($reportRecord['id']); ?>" target="_blank" class="button secondary">PDF</a>
                            <form method="POST" action="index.php?action=report_delete" class="inline-form" onsubmit="return confirm('Are you sure you want to permanently delete this report?');">
                                <input type="hidden" name="id" value="<?php echo htmlspecialchars((string)$reportRecord['id']); ?>">
                                <button type="submit" class="button danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/footer.php'; ?>
