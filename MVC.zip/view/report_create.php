<?php require __DIR__ . '/header.php'; ?>

<div class="panel" style="max-width: 650px; margin: 25px auto;">
    <h2>Create Blood Report</h2>
    <div style="margin-bottom: 20px; padding: 10px; background-color: #f7f7f7; border: 1px solid #cccccc;">
        <strong>Patient:</strong> <?php echo htmlspecialchars($patientRecord['name']); ?> |
        <strong>Age:</strong> <?php echo htmlspecialchars((string)$patientRecord['age']); ?> |
        <strong>Gender:</strong> <?php echo htmlspecialchars($patientRecord['gender']); ?>
    </div>

    <?php if (!empty($errorMessage)): ?>
        <div class="alert-error"><?php echo htmlspecialchars($errorMessage); ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php?action=report_create&patient_id=<?php echo urlencode($patientRecord['id']); ?>">
        <div>
            <label for="report_type">Select Report Type</label>
            <select id="report_type" name="report_type" onchange="toggleTestPanels(this.value);" required>
                <option value="FBC">Full Blood Count (FBC)</option>
                <option value="Lipid Profile">Lipid Profile</option>
                <option value="Blood Sugar">Blood Sugar</option>
            </select>
        </div>

        <div id="panel_fbc" class="field-box">
            <h3>Full Blood Count (FBC) Parameters</h3>
            <div>
                <label for="hemoglobin">Hemoglobin (g/dL)</label>
                <input type="text" id="hemoglobin" name="hemoglobin" placeholder="e.g. 14.5">
            </div>
            <div>
                <label for="white_blood_cells">White Blood Cell Count (x10^9/L)</label>
                <input type="text" id="white_blood_cells" name="white_blood_cells" placeholder="e.g. 7.2">
            </div>
            <div>
                <label for="red_blood_cells">Red Blood Cell Count (x10^12/L)</label>
                <input type="text" id="red_blood_cells" name="red_blood_cells" placeholder="e.g. 4.8">
            </div>
            <div>
                <label for="platelets">Platelet Count (x10^9/L)</label>
                <input type="text" id="platelets" name="platelets" placeholder="e.g. 250">
            </div>
            <div>
                <label for="hematocrit">Hematocrit (%)</label>
                <input type="text" id="hematocrit" name="hematocrit" placeholder="e.g. 42">
            </div>
        </div>

        <div id="panel_lipid" class="field-box" style="display: none;">
            <h3>Lipid Profile Parameters</h3>
            <div>
                <label for="total_cholesterol">Total Cholesterol (mg/dL)</label>
                <input type="text" id="total_cholesterol" name="total_cholesterol" placeholder="e.g. 195">
            </div>
            <div>
                <label for="triglycerides">Triglycerides (mg/dL)</label>
                <input type="text" id="triglycerides" name="triglycerides" placeholder="e.g. 140">
            </div>
            <div>
                <label for="hdl_cholesterol">HDL Cholesterol (mg/dL)</label>
                <input type="text" id="hdl_cholesterol" name="hdl_cholesterol" placeholder="e.g. 52">
            </div>
            <div>
                <label for="ldl_cholesterol">LDL Cholesterol (mg/dL)</label>
                <input type="text" id="ldl_cholesterol" name="ldl_cholesterol" placeholder="e.g. 115">
            </div>
        </div>

        <div id="panel_sugar" class="field-box" style="display: none;">
            <h3>Blood Sugar Parameters</h3>
            <div>
                <label for="fasting_blood_sugar">Fasting Blood Sugar (mg/dL)</label>
                <input type="text" id="fasting_blood_sugar" name="fasting_blood_sugar" placeholder="e.g. 92">
            </div>
            <div>
                <label for="postprandial_blood_sugar">Postprandial Blood Sugar (mg/dL)</label>
                <input type="text" id="postprandial_blood_sugar" name="postprandial_blood_sugar" placeholder="e.g. 130">
            </div>
            <div>
                <label for="hba1c">HbA1c (%)</label>
                <input type="text" id="hba1c" name="hba1c" placeholder="e.g. 5.4">
            </div>
        </div>

        <div style="margin-top: 20px;">
            <button type="submit" class="button">Save Report</button>
            <a href="index.php?action=patient_view&id=<?php echo urlencode($patientRecord['id']); ?>" class="button secondary">Cancel</a>
        </div>
    </form>
</div>

<script>
function toggleTestPanels(selectedType) {
    document.getElementById('panel_fbc').style.display = (selectedType === 'FBC') ? 'block' : 'none';
    document.getElementById('panel_lipid').style.display = (selectedType === 'Lipid Profile') ? 'block' : 'none';
    document.getElementById('panel_sugar').style.display = (selectedType === 'Blood Sugar') ? 'block' : 'none';
}
</script>

<?php require __DIR__ . '/footer.php'; ?>
