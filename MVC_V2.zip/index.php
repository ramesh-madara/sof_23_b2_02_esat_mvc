<?php

session_start();

$requestedAction = $_GET['action'] ?? 'patients';

switch ($requestedAction) {
    case 'login':
        require_once __DIR__ . '/controller/AuthenticationController.php';
        $authenticationController = new AuthenticationController();
        $authenticationController->login();
        break;

    case 'logout':
        require_once __DIR__ . '/controller/AuthenticationController.php';
        $authenticationController = new AuthenticationController();
        $authenticationController->logout();
        break;

    case 'register':
        require_once __DIR__ . '/controller/AccountController.php';
        $accountController = new AccountController();
        $accountController->register();
        break;

    case 'account':
        require_once __DIR__ . '/controller/AccountController.php';
        $accountController = new AccountController();
        $accountController->manage();
        break;

    case 'patients':
        require_once __DIR__ . '/controller/PatientController.php';
        $patientController = new PatientController();
        $patientController->index();
        break;

    case 'patient_create':
        require_once __DIR__ . '/controller/PatientController.php';
        $patientController = new PatientController();
        $patientController->create();
        break;

    case 'patient_view':
        require_once __DIR__ . '/controller/PatientController.php';
        $patientController = new PatientController();
        $patientController->view();
        break;

    case 'report_create':
        require_once __DIR__ . '/controller/ReportController.php';
        $reportController = new ReportController();
        $reportController->create();
        break;

    case 'report_view':
        require_once __DIR__ . '/controller/ReportController.php';
        $reportController = new ReportController();
        $reportController->view();
        break;

    case 'report_edit':
        require_once __DIR__ . '/controller/ReportController.php';
        $reportController = new ReportController();
        $reportController->edit();
        break;

    case 'report_delete':
        require_once __DIR__ . '/controller/ReportController.php';
        $reportController = new ReportController();
        $reportController->delete();
        break;

    case 'report_pdf':
        require_once __DIR__ . '/controller/ReportController.php';
        $reportController = new ReportController();
        $reportController->exportPdf();
        break;

    default:
        header('Location: index.php?action=patients');
        exit;
}
