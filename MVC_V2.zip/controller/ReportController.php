<?php

require_once __DIR__ . '/../model/PatientModel.php';
require_once __DIR__ . '/../model/ReportModel.php';
require_once __DIR__ . '/../libs/fpdf.php';

class ReportController
{
    private PatientModel $patientModel;
    private ReportModel $reportModel;

    public function __construct()
    {
        $this->patientModel = new PatientModel();
        $this->reportModel = new ReportModel();
    }

    private function ensureDoctorIsAuthenticated(): int
    {
        if (!isset($_SESSION['doctor_id'])) {
            header('Location: index.php?action=login');
            exit;
        }
        return (int)$_SESSION['doctor_id'];
    }

    private function validateNumericReading(?string $value): bool
    {
        if ($value === null || trim($value) === '') {
            return false;
        }
        return is_numeric($value) && (float)$value >= 0;
    }

    public function create(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $patientIdentifier = (int)($_GET['patient_id'] ?? 0);

        $patientRecord = $this->patientModel->getPatientByIdAndDoctorId($patientIdentifier, $doctorIdentifier);

        if (!$patientRecord) {
            header('Location: index.php?action=patients&error=unauthorized');
            exit;
        }

        $errorMessage = '';

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            $reportType = trim($_POST['report_type'] ?? '');
            $bloodTestResults = [];

            if ($reportType === 'FBC') {
                $hemoglobin = trim($_POST['hemoglobin'] ?? '');
                $whiteBloodCells = trim($_POST['white_blood_cells'] ?? '');
                $redBloodCells = trim($_POST['red_blood_cells'] ?? '');
                $platelets = trim($_POST['platelets'] ?? '');
                $hematocrit = trim($_POST['hematocrit'] ?? '');

                if (
                    !$this->validateNumericReading($hemoglobin) ||
                    !$this->validateNumericReading($whiteBloodCells) ||
                    !$this->validateNumericReading($redBloodCells) ||
                    !$this->validateNumericReading($platelets) ||
                    !$this->validateNumericReading($hematocrit)
                ) {
                    $errorMessage = 'All Full Blood Count parameters are required and must be valid non-negative numbers.';
                } else {
                    $bloodTestResults = [
                        'Hemoglobin (g/dL)' => $hemoglobin,
                        'White Blood Cell Count (x10^9/L)' => $whiteBloodCells,
                        'Red Blood Cell Count (x10^12/L)' => $redBloodCells,
                        'Platelet Count (x10^9/L)' => $platelets,
                        'Hematocrit (%)' => $hematocrit,
                    ];
                }
            } elseif ($reportType === 'Lipid Profile') {
                $totalCholesterol = trim($_POST['total_cholesterol'] ?? '');
                $triglycerides = trim($_POST['triglycerides'] ?? '');
                $hdlCholesterol = trim($_POST['hdl_cholesterol'] ?? '');
                $ldlCholesterol = trim($_POST['ldl_cholesterol'] ?? '');

                if (
                    !$this->validateNumericReading($totalCholesterol) ||
                    !$this->validateNumericReading($triglycerides) ||
                    !$this->validateNumericReading($hdlCholesterol) ||
                    !$this->validateNumericReading($ldlCholesterol)
                ) {
                    $errorMessage = 'All Lipid Profile parameters are required and must be valid non-negative numbers.';
                } else {
                    $bloodTestResults = [
                        'Total Cholesterol (mg/dL)' => $totalCholesterol,
                        'Triglycerides (mg/dL)' => $triglycerides,
                        'HDL Cholesterol (mg/dL)' => $hdlCholesterol,
                        'LDL Cholesterol (mg/dL)' => $ldlCholesterol,
                    ];
                }
            } elseif ($reportType === 'Blood Sugar') {
                $fastingBloodSugar = trim($_POST['fasting_blood_sugar'] ?? '');
                $postprandialBloodSugar = trim($_POST['postprandial_blood_sugar'] ?? '');
                $hba1c = trim($_POST['hba1c'] ?? '');

                if (
                    !$this->validateNumericReading($fastingBloodSugar) ||
                    !$this->validateNumericReading($postprandialBloodSugar) ||
                    !$this->validateNumericReading($hba1c)
                ) {
                    $errorMessage = 'All Blood Sugar parameters are required and must be valid non-negative numbers.';
                } else {
                    $bloodTestResults = [
                        'Fasting Blood Sugar (mg/dL)' => $fastingBloodSugar,
                        'Postprandial Blood Sugar (mg/dL)' => $postprandialBloodSugar,
                        'HbA1c (%)' => $hba1c,
                    ];
                }
            } else {
                $errorMessage = 'Please select a valid report type.';
            }

            if (empty($errorMessage)) {
                $reportDataJson = json_encode($bloodTestResults);
                $creationSuccessful = $this->reportModel->createReport(
                    $patientIdentifier,
                    $doctorIdentifier,
                    $reportType,
                    $reportDataJson
                );

                if ($creationSuccessful) {
                    header('Location: index.php?action=patient_view&id=' . $patientIdentifier . '&report_created=1');
                    exit;
                } else {
                    $errorMessage = 'Failed to generate blood report.';
                }
            }
        }

        require __DIR__ . '/../view/report_create.php';
    }

    public function view(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $reportIdentifier = (int)($_GET['id'] ?? 0);

        $reportRecord = $this->reportModel->getReportByIdAndDoctorId($reportIdentifier, $doctorIdentifier);

        if (!$reportRecord) {
            header('Location: index.php?action=patients&error=notfound');
            exit;
        }

        $bloodTestResults = json_decode($reportRecord['data'], true) ?? [];

        require __DIR__ . '/../view/report_view.php';
    }

    public function edit(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $reportIdentifier = (int)($_GET['id'] ?? 0);

        $reportRecord = $this->reportModel->getReportByIdAndDoctorId($reportIdentifier, $doctorIdentifier);

        if (!$reportRecord) {
            header('Location: index.php?action=patients&error=unauthorized');
            exit;
        }

        $errorMessage = '';
        $bloodTestResults = json_decode($reportRecord['data'], true) ?? [];

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            $reportType = trim($_POST['report_type'] ?? '');
            $newTestResults = [];

            if ($reportType === 'FBC') {
                $hemoglobin = trim($_POST['hemoglobin'] ?? '');
                $whiteBloodCells = trim($_POST['white_blood_cells'] ?? '');
                $redBloodCells = trim($_POST['red_blood_cells'] ?? '');
                $platelets = trim($_POST['platelets'] ?? '');
                $hematocrit = trim($_POST['hematocrit'] ?? '');

                if (
                    !$this->validateNumericReading($hemoglobin) ||
                    !$this->validateNumericReading($whiteBloodCells) ||
                    !$this->validateNumericReading($redBloodCells) ||
                    !$this->validateNumericReading($platelets) ||
                    !$this->validateNumericReading($hematocrit)
                ) {
                    $errorMessage = 'All Full Blood Count parameters are required and must be valid non-negative numbers.';
                } else {
                    $newTestResults = [
                        'Hemoglobin (g/dL)' => $hemoglobin,
                        'White Blood Cell Count (x10^9/L)' => $whiteBloodCells,
                        'Red Blood Cell Count (x10^12/L)' => $redBloodCells,
                        'Platelet Count (x10^9/L)' => $platelets,
                        'Hematocrit (%)' => $hematocrit,
                    ];
                }
            } elseif ($reportType === 'Lipid Profile') {
                $totalCholesterol = trim($_POST['total_cholesterol'] ?? '');
                $triglycerides = trim($_POST['triglycerides'] ?? '');
                $hdlCholesterol = trim($_POST['hdl_cholesterol'] ?? '');
                $ldlCholesterol = trim($_POST['ldl_cholesterol'] ?? '');

                if (
                    !$this->validateNumericReading($totalCholesterol) ||
                    !$this->validateNumericReading($triglycerides) ||
                    !$this->validateNumericReading($hdlCholesterol) ||
                    !$this->validateNumericReading($ldlCholesterol)
                ) {
                    $errorMessage = 'All Lipid Profile parameters are required and must be valid non-negative numbers.';
                } else {
                    $newTestResults = [
                        'Total Cholesterol (mg/dL)' => $totalCholesterol,
                        'Triglycerides (mg/dL)' => $triglycerides,
                        'HDL Cholesterol (mg/dL)' => $hdlCholesterol,
                        'LDL Cholesterol (mg/dL)' => $ldlCholesterol,
                    ];
                }
            } elseif ($reportType === 'Blood Sugar') {
                $fastingBloodSugar = trim($_POST['fasting_blood_sugar'] ?? '');
                $postprandialBloodSugar = trim($_POST['postprandial_blood_sugar'] ?? '');
                $hba1c = trim($_POST['hba1c'] ?? '');

                if (
                    !$this->validateNumericReading($fastingBloodSugar) ||
                    !$this->validateNumericReading($postprandialBloodSugar) ||
                    !$this->validateNumericReading($hba1c)
                ) {
                    $errorMessage = 'All Blood Sugar parameters are required and must be valid non-negative numbers.';
                } else {
                    $newTestResults = [
                        'Fasting Blood Sugar (mg/dL)' => $fastingBloodSugar,
                        'Postprandial Blood Sugar (mg/dL)' => $postprandialBloodSugar,
                        'HbA1c (%)' => $hba1c,
                    ];
                }
            } else {
                $errorMessage = 'Please select a valid report type.';
            }

            if (empty($errorMessage)) {
                $reportDataJson = json_encode($newTestResults);
                $updateSuccessful = $this->reportModel->updateReport(
                    $reportIdentifier,
                    $doctorIdentifier,
                    $reportType,
                    $reportDataJson
                );

                if ($updateSuccessful) {
                    header('Location: index.php?action=report_view&id=' . $reportIdentifier . '&updated=1');
                    exit;
                } else {
                    $errorMessage = 'Failed to update the report.';
                }
            }
        }

        require __DIR__ . '/../view/report_edit.php';
    }

    public function delete(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $reportIdentifier = (int)($_POST['id'] ?? $_GET['id'] ?? 0);

        $reportRecord = $this->reportModel->getReportByIdAndDoctorId($reportIdentifier, $doctorIdentifier);

        if ($reportRecord) {
            $patientIdentifier = (int)$reportRecord['patient_id'];
            $this->reportModel->deleteReport($reportIdentifier, $doctorIdentifier);
            header('Location: index.php?action=patient_view&id=' . $patientIdentifier . '&deleted=1');
            exit;
        }

        header('Location: index.php?action=patients&error=unauthorized');
        exit;
    }

    public function exportPdf(): void
    {
        $doctorIdentifier = $this->ensureDoctorIsAuthenticated();
        $reportIdentifier = (int)($_GET['id'] ?? 0);

        $reportRecord = $this->reportModel->getReportByIdAndDoctorId($reportIdentifier, $doctorIdentifier);

        if (!$reportRecord) {
            header('Location: index.php?action=patients&error=notfound');
            exit;
        }

        $bloodTestResults = json_decode($reportRecord['data'], true) ?? [];

        $pdf = new FPDF();
        $pdf->AddPage();

        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'BLOOD TEST REPORT', 0, 1, 'L');
        $pdf->Ln(4);

        $pdf->SetFont('Arial', '', 11);
        $pdf->Cell(45, 8, 'Patient Name:', 1, 0);
        $pdf->Cell(0, 8, $reportRecord['patient_name'], 1, 1);

        $pdf->Cell(45, 8, 'Patient Age:', 1, 0);
        $pdf->Cell(0, 8, (string)$reportRecord['patient_age'] . ' Years', 1, 1);

        $pdf->Cell(45, 8, 'Patient Gender:', 1, 0);
        $pdf->Cell(0, 8, $reportRecord['patient_gender'], 1, 1);

        $pdf->Cell(45, 8, 'Attending Doctor:', 1, 0);
        $pdf->Cell(0, 8, $_SESSION['doctor_username'], 1, 1);

        $pdf->Cell(45, 8, 'Report Type:', 1, 0);
        $pdf->Cell(0, 8, $reportRecord['type'], 1, 1);

        $pdf->Cell(45, 8, 'Generated Date:', 1, 0);
        $pdf->Cell(0, 8, $reportRecord['created_at'], 1, 1);
        $pdf->Ln(6);

        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(110, 8, 'Test Parameter', 1, 0, 'L');
        $pdf->Cell(70, 8, 'Observed Result', 1, 1, 'L');

        $pdf->SetFont('Arial', '', 10);
        foreach ($bloodTestResults as $testParameter => $testValue) {
            $pdf->Cell(110, 7, (string)$testParameter, 1, 0, 'L');
            $pdf->Cell(70, 7, (string)$testValue, 1, 1, 'L');
        }

        $destinationMode = isset($_GET['download']) ? 'D' : 'I';
        $pdf->Output($destinationMode, 'Blood_Report_' . $reportIdentifier . '.pdf');
        exit;
    }
}
