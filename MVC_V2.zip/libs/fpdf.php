<?php

class FPDF
{
    private string $pageOrientation;
    private string $measurementUnit;
    private string $pageSize;
    private float $pageWidth;
    private float $pageHeight;
    private float $currentX;
    private float $currentY;
    private float $leftMargin;
    private float $topMargin;
    private float $rightMargin;
    private string $currentFont;
    private float $currentFontSize;
    private array $pages;
    private int $pageNumber;

    public function __construct(string $pageOrientation = 'P', string $measurementUnit = 'mm', string $pageSize = 'A4')
    {
        $this->pageOrientation = $pageOrientation;
        $this->measurementUnit = $measurementUnit;
        $this->pageSize = $pageSize;
        $this->pageWidth = 595.28;
        $this->pageHeight = 841.89;
        $this->leftMargin = 28.35;
        $this->topMargin = 28.35;
        $this->rightMargin = 28.35;
        $this->currentX = $this->leftMargin;
        $this->currentY = $this->topMargin;
        $this->currentFont = '/F1';
        $this->currentFontSize = 12.0;
        $this->pages = [];
        $this->pageNumber = 0;
    }

    public function AddPage(string $pageOrientation = '', string $pageSize = '', int $pageRotation = 0): void
    {
        $this->pageNumber++;
        $this->pages[$this->pageNumber] = '';
        $this->currentX = $this->leftMargin;
        $this->currentY = $this->topMargin;
    }

    public function SetFont(string $fontFamily, string $fontStyle = '', float $fontSize = 0.0): void
    {
        $this->currentFont = (strpos(strtoupper($fontStyle), 'B') !== false) ? '/F2' : '/F1';
        if ($fontSize > 0) {
            $this->currentFontSize = $fontSize;
        }
    }

    public function Cell(float $cellWidth, float $cellHeight = 0.0, string $textString = '', $cellBorder = 0, int $lineBreak = 0, string $textAlignment = '', bool $cellFill = false, string $hyperLink = ''): void
    {
        $actualWidth = ($cellWidth == 0) ? ($this->pageWidth - $this->leftMargin - $this->rightMargin) : ($cellWidth * 2.83465);
        $actualHeight = ($cellHeight == 0) ? ($this->currentFontSize * 1.25) : ($cellHeight * 2.83465);

        $pdfX = $this->currentX;
        $pdfY = $this->pageHeight - $this->currentY - $actualHeight;

        $contentStream = '';
        if ($cellBorder) {
            $contentStream .= sprintf("0 0 0 RG 0.5 w %.2F %.2F %.2F %.2F re S\n", $pdfX, $pdfY, $actualWidth, $actualHeight);
        }

        $escapedText = strtr($textString, [')' => '\\)', '(' => '\\(', '\\' => '\\\\']);
        $textX = $pdfX + 3.0;
        $textY = $pdfY + ($actualHeight / 2) - ($this->currentFontSize * 0.35);

        if ($textAlignment === 'C') {
            $textX = $pdfX + ($actualWidth / 2) - (strlen($textString) * $this->currentFontSize * 0.28);
        } elseif ($textAlignment === 'R') {
            $textX = $pdfX + $actualWidth - (strlen($textString) * $this->currentFontSize * 0.55) - 3.0;
        }

        $contentStream .= "BT\n";
        $contentStream .= "0 g\n";
        $contentStream .= sprintf("%s %.2F Tf\n", $this->currentFont, $this->currentFontSize);
        $contentStream .= sprintf("%.2F %.2F Td\n", $textX, $textY);
        $contentStream .= sprintf("(%s) Tj\n", $escapedText);
        $contentStream .= "ET\n";

        $this->pages[$this->pageNumber] .= $contentStream;

        if ($lineBreak > 0) {
            $this->currentY += $actualHeight;
            $this->currentX = $this->leftMargin;
        } else {
            $this->currentX += $actualWidth;
        }
    }

    public function Ln(float $lineHeight = 0.0): void
    {
        $actualHeight = ($lineHeight > 0) ? ($lineHeight * 2.83465) : ($this->currentFontSize * 1.25);
        $this->currentX = $this->leftMargin;
        $this->currentY += $actualHeight;
    }

    public function Output(string $destinationMode = 'I', string $documentName = 'document.pdf', bool $isUtf8 = false): string
    {
        $pdfBuffer = "%PDF-1.4\n";
        $objectOffsets = [];

        $objectOffsets[1] = strlen($pdfBuffer);
        $pdfBuffer .= "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";

        $pageReferences = [];
        for ($pageIndex = 1; $pageIndex <= $this->pageNumber; $pageIndex++) {
            $pageObjectNumber = 5 + ($pageIndex - 1) * 2;
            $pageReferences[] = "{$pageObjectNumber} 0 R";
        }
        $pagesListString = implode(' ', $pageReferences);

        $objectOffsets[2] = strlen($pdfBuffer);
        $pdfBuffer .= "2 0 obj\n<< /Type /Pages /Kids [{$pagesListString}] /Count {$this->pageNumber} >>\nendobj\n";

        $objectOffsets[3] = strlen($pdfBuffer);
        $pdfBuffer .= "3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj\n";

        $objectOffsets[4] = strlen($pdfBuffer);
        $pdfBuffer .= "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj\n";

        $nextObjectNumber = 5;
        for ($pageIndex = 1; $pageIndex <= $this->pageNumber; $pageIndex++) {
            $pageObjectNumber = $nextObjectNumber++;
            $streamObjectNumber = $nextObjectNumber++;

            $streamContent = $this->pages[$pageIndex];
            $streamLength = strlen($streamContent);

            $objectOffsets[$pageObjectNumber] = strlen($pdfBuffer);
            $pdfBuffer .= "{$pageObjectNumber} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Contents {$streamObjectNumber} 0 R /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> >>\nendobj\n";

            $objectOffsets[$streamObjectNumber] = strlen($pdfBuffer);
            $pdfBuffer .= "{$streamObjectNumber} 0 obj\n<< /Length {$streamLength} >>\nstream\n{$streamContent}endstream\nendobj\n";
        }

        $crossReferenceOffset = strlen($pdfBuffer);
        $totalObjects = $nextObjectNumber;
        $pdfBuffer .= "xref\n0 {$totalObjects}\n";
        $pdfBuffer .= "0000000000 65535 f \r\n";
        for ($objectIndex = 1; $objectIndex < $totalObjects; $objectIndex++) {
            $pdfBuffer .= sprintf("%010d 00000 n \r\n", $objectOffsets[$objectIndex]);
        }

        $pdfBuffer .= "trailer\n<< /Size {$totalObjects} /Root 1 0 R >>\n";
        $pdfBuffer .= "startxref\n{$crossReferenceOffset}\n%%EOF\n";

        if ($destinationMode === 'I' || $destinationMode === 'D') {
            header('Content-Type: application/pdf');
            header('Content-Length: ' . strlen($pdfBuffer));
            $dispositionType = ($destinationMode === 'D') ? 'attachment' : 'inline';
            header("Content-Disposition: {$dispositionType}; filename=\"{$documentName}\"");
            echo $pdfBuffer;
            exit;
        }

        return $pdfBuffer;
    }
}
