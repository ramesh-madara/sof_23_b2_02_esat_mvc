<?php

require_once __DIR__ . '/Database.php';

class DoctorModel
{
    private PDO $databaseConnection;

    public function __construct()
    {
        $this->databaseConnection = Database::getConnection();
    }

    public function findDoctorByUsername(string $username): ?array
    {
        $statement = $this->databaseConnection->prepare("SELECT * FROM doctors WHERE username = :username LIMIT 1");
        $statement->execute([':username' => $username]);
        $doctorRecord = $statement->fetch();
        return $doctorRecord ?: null;
    }

    public function findDoctorById(int $doctorIdentifier): ?array
    {
        $statement = $this->databaseConnection->prepare("SELECT id, username, password FROM doctors WHERE id = :id LIMIT 1");
        $statement->execute([':id' => $doctorIdentifier]);
        $doctorRecord = $statement->fetch();
        return $doctorRecord ?: null;
    }

    public function createDoctor(string $username, string $hashedPassword): bool
    {
        $statement = $this->databaseConnection->prepare("INSERT INTO doctors (username, password) VALUES (:username, :password)");
        return $statement->execute([
            ':username' => $username,
            ':password' => $hashedPassword,
        ]);
    }

    public function updateDoctorPassword(int $doctorIdentifier, string $hashedPassword): bool
    {
        $statement = $this->databaseConnection->prepare("UPDATE doctors SET password = :password WHERE id = :id");
        return $statement->execute([
            ':password' => $hashedPassword,
            ':id' => $doctorIdentifier,
        ]);
    }
}
