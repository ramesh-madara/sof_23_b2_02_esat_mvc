<?php

require_once __DIR__ . '/Database.php';

class ReportModel
{
    private PDO $databaseConnection;

    public function __construct()
    {
        $this->databaseConnection = Database::getConnection();
    }

    public function createReport(int $patientIdentifier, int $doctorIdentifier, string $reportType, string $reportDataJson): bool
    {
        $verificationStatement = $this->databaseConnection->prepare("SELECT id FROM patients WHERE id = :patient_id AND doctor_id = :doctor_id LIMIT 1");
        $verificationStatement->execute([
            ':patient_id' => $patientIdentifier,
            ':doctor_id' => $doctorIdentifier,
        ]);
        $verifiedPatient = $verificationStatement->fetch();

        if (!$verifiedPatient) {
            return false;
        }

        $statement = $this->databaseConnection->prepare("INSERT INTO reports (patient_id, type, data) VALUES (:patient_id, :type, :data)");
        return $statement->execute([
            ':patient_id' => $patientIdentifier,
            ':type' => $reportType,
            ':data' => $reportDataJson,
        ]);
    }

    public function getReportsByPatientIdAndDoctorId(int $patientIdentifier, int $doctorIdentifier): array
    {
        $statement = $this->databaseConnection->prepare("
            SELECT reports.* 
            FROM reports 
            INNER JOIN patients ON reports.patient_id = patients.id 
            WHERE reports.patient_id = :patient_id AND patients.doctor_id = :doctor_id 
            ORDER BY reports.created_at DESC
        ");
        $statement->execute([
            ':patient_id' => $patientIdentifier,
            ':doctor_id' => $doctorIdentifier,
        ]);
        return $statement->fetchAll();
    }

    public function getReportByIdAndDoctorId(int $reportIdentifier, int $doctorIdentifier): ?array
    {
        $statement = $this->databaseConnection->prepare("
            SELECT reports.*, patients.name AS patient_name, patients.age AS patient_age, patients.gender AS patient_gender, patients.doctor_id 
            FROM reports 
            INNER JOIN patients ON reports.patient_id = patients.id 
            WHERE reports.id = :report_id AND patients.doctor_id = :doctor_id 
            LIMIT 1
        ");
        $statement->execute([
            ':report_id' => $reportIdentifier,
            ':doctor_id' => $doctorIdentifier,
        ]);
        $reportRecord = $statement->fetch();
        return $reportRecord ?: null;
    }

    public function updateReport(int $reportIdentifier, int $doctorIdentifier, string $reportType, string $reportDataJson): bool
    {
        $statement = $this->databaseConnection->prepare("
            UPDATE reports 
            INNER JOIN patients ON reports.patient_id = patients.id 
            SET reports.type = :type, reports.data = :data 
            WHERE reports.id = :report_id AND patients.doctor_id = :doctor_id
        ");
        return $statement->execute([
            ':type' => $reportType,
            ':data' => $reportDataJson,
            ':report_id' => $reportIdentifier,
            ':doctor_id' => $doctorIdentifier,
        ]);
    }

    public function deleteReport(int $reportIdentifier, int $doctorIdentifier): bool
    {
        $statement = $this->databaseConnection->prepare("
            DELETE reports FROM reports 
            INNER JOIN patients ON reports.patient_id = patients.id 
            WHERE reports.id = :report_id AND patients.doctor_id = :doctor_id
        ");
        return $statement->execute([
            ':report_id' => $reportIdentifier,
            ':doctor_id' => $doctorIdentifier,
        ]);
    }
}
