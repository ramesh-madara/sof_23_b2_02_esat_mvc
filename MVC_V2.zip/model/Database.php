<?php

class Database
{
    private static ?PDO $connectionInstance = null;

    public static function getConnection(): PDO
    {
        if (self::$connectionInstance === null) {
            $databaseHost = '127.0.0.1';
            $databaseName = 'blood_report_system';
            $databaseUser = 'root';
            $databasePassword = '';

            try {
                $dataConfiguration = "mysql:host={$databaseHost};dbname={$databaseName};charset=utf8mb4";
                self::$connectionInstance = new PDO($dataConfiguration, $databaseUser, $databasePassword, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
            } catch (PDOException $databaseException) {
                $fallbackConfiguration = "mysql:host={$databaseHost};charset=utf8mb4";
                $temporaryConnection = new PDO($fallbackConfiguration, $databaseUser, $databasePassword, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                ]);
                $temporaryConnection->exec("CREATE DATABASE IF NOT EXISTS `{$databaseName}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                $temporaryConnection->exec("USE `{$databaseName}`");
                $temporaryConnection->exec("
                    CREATE TABLE IF NOT EXISTS doctors (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        username VARCHAR(50) NOT NULL UNIQUE,
                        password VARCHAR(255) NOT NULL
                    ) ENGINE=InnoDB;
                    CREATE TABLE IF NOT EXISTS patients (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        doctor_id INT NOT NULL,
                        name VARCHAR(100) NOT NULL,
                        age INT NOT NULL,
                        gender VARCHAR(20) NOT NULL,
                        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB;
                    CREATE TABLE IF NOT EXISTS reports (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        patient_id INT NOT NULL,
                        type VARCHAR(50) NOT NULL,
                        data TEXT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB;
                ");
                $dataConfiguration = "mysql:host={$databaseHost};dbname={$databaseName};charset=utf8mb4";
                self::$connectionInstance = new PDO($dataConfiguration, $databaseUser, $databasePassword, [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
            }
        }
        return self::$connectionInstance;
    }
}
