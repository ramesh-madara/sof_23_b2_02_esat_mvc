<?php

require_once __DIR__ . '/Database.php';

class PatientModel
{
    private PDO $databaseConnection;

    public function __construct()
    {
        $this->databaseConnection = Database::getConnection();
    }

    public function createPatient(int $doctorIdentifier, string $patientName, int $patientAge, string $patientGender): bool
    {
        $statement = $this->databaseConnection->prepare("INSERT INTO patients (doctor_id, name, age, gender) VALUES (:doctor_id, :name, :age, :gender)");
        return $statement->execute([
            ':doctor_id' => $doctorIdentifier,
            ':name' => $patientName,
            ':age' => $patientAge,
            ':gender' => $patientGender,
        ]);
    }

    public function getPatientsByDoctorId(int $doctorIdentifier): array
    {
        $statement = $this->databaseConnection->prepare("SELECT * FROM patients WHERE doctor_id = :doctor_id ORDER BY id DESC");
        $statement->execute([':doctor_id' => $doctorIdentifier]);
        return $statement->fetchAll();
    }

    public function searchAndFilterPatients(
        int $doctorIdentifier,
        string $searchTerm = '',
        string $genderFilter = '',
        ?int $minimumAge = null,
        ?int $maximumAge = null,
        string $reportStatusFilter = '',
        string $sortOption = 'id_desc'
    ): array {
        $baseQuery = "
            SELECT patients.*, COUNT(reports.id) AS report_count
            FROM patients
            LEFT JOIN reports ON patients.id = reports.patient_id
            WHERE patients.doctor_id = :doctor_id
        ";
        $queryParameters = [
            ':doctor_id' => $doctorIdentifier,
        ];

        if (!empty($searchTerm)) {
            $baseQuery .= " AND (patients.name LIKE :search_name OR patients.id = :search_id)";
            $queryParameters[':search_name'] = '%' . $searchTerm . '%';
            $queryParameters[':search_id'] = is_numeric($searchTerm) ? (int)$searchTerm : 0;
        }

        if (!empty($genderFilter) && in_array($genderFilter, ['Male', 'Female', 'Other'], true)) {
            $baseQuery .= " AND patients.gender = :gender";
            $queryParameters[':gender'] = $genderFilter;
        }

        if ($minimumAge !== null && $minimumAge > 0) {
            $baseQuery .= " AND patients.age >= :minimum_age";
            $queryParameters[':minimum_age'] = $minimumAge;
        }

        if ($maximumAge !== null && $maximumAge > 0) {
            $baseQuery .= " AND patients.age <= :maximum_age";
            $queryParameters[':maximum_age'] = $maximumAge;
        }

        $baseQuery .= " GROUP BY patients.id";

        if ($reportStatusFilter === 'with_reports') {
            $baseQuery .= " HAVING report_count > 0";
        } elseif ($reportStatusFilter === 'without_reports') {
            $baseQuery .= " HAVING report_count = 0";
        }

        $sortSqlMap = [
            'id_desc' => 'patients.id DESC',
            'id_asc' => 'patients.id ASC',
            'name_asc' => 'patients.name ASC',
            'name_desc' => 'patients.name DESC',
            'age_asc' => 'patients.age ASC',
            'age_desc' => 'patients.age DESC',
            'reports_desc' => 'report_count DESC, patients.id DESC',
        ];

        $orderByClause = $sortSqlMap[$sortOption] ?? 'patients.id DESC';
        $baseQuery .= " ORDER BY " . $orderByClause;

        $statement = $this->databaseConnection->prepare($baseQuery);
        $statement->execute($queryParameters);
        return $statement->fetchAll();
    }

    public function getPatientByIdAndDoctorId(int $patientIdentifier, int $doctorIdentifier): ?array
    {
        $statement = $this->databaseConnection->prepare("SELECT * FROM patients WHERE id = :id AND doctor_id = :doctor_id LIMIT 1");
        $statement->execute([
            ':id' => $patientIdentifier,
            ':doctor_id' => $doctorIdentifier,
        ]);
        $patientRecord = $statement->fetch();
        return $patientRecord ?: null;
    }
}
